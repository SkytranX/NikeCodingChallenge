package com.example.nikecodingchallenge.constant

const val BASE_URL = "https://mashape-community-urban-dictionary.p.rapidapi.com"
const val SEARCH_PATH = "/define"
const val API_KEY = "3dee3aef91msh363dcc1c096fcaap1b0ac6jsnc193da2a47e9"
const val API_HOST = "mashape-community-urban-dictionary.p.rapidapi.com"