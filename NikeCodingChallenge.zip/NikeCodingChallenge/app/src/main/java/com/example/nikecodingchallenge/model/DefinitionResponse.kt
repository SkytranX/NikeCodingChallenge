package com.example.nikecodingchallenge.model

data class DefinitionResponse(
    val list: List<Definition>
)